from flask import Blueprint
from config import db
m1bp = Blueprint('m1bp',__name__,url_prefix='/m1bp')
print(db)
@m1bp.route('/m1')
def m1():
    return "This is M1 method in module1"