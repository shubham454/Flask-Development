from config import app , db
from module2.module2blueprint import m2bp
from module1.module1blueprint import m1bp
app.register_blueprint(m1bp)
app.register_blueprint(m2bp)
print(__name__)
if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)