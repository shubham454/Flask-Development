from flask import Blueprint
from config import db
m2bp = Blueprint('m2bp',__name__,url_prefix='/m2bp')
print(db)
@m2bp.route('/m2')
def m2():
    return "this is m2 method of m2bp"