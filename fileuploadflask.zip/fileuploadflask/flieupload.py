from flask import Flask,render_template,request,flash,redirect,send_from_directory
from flask_sqlalchemy import  SQLAlchemy
from werkzeug.utils import secure_filename
import os
app = Flask(__name__)
app.debug = True
app.secret_key = "dgasfsfgfwsdfwef"
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost:3307/flask'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['UPLOAD_FOLDER'] = os.path.join(BASE_DIR,'media')
db = SQLAlchemy(app=app)


class FileUpload(db.Model):
    fid = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(50))


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload',methods=['GET','POST'])
def uploadview():
    print(request.url)
    if request.form and 'file' in  request.files:
        files = request.files['file']
        if files.filename =='':
            flash('No files attached','error')
            return redirect(request.url)
        print(files.filename)
        filename = secure_filename(files.filename)
        print(filename)
        files.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))
        f = FileUpload(filename=filename)
        print(f.filename)
        db.session.add(f)
        db.session.commit()
        fdata = FileUpload.query.all()
        return render_template('success.html',fdata=fdata)

    else:
        return render_template('index.html')

@app.route('/download/<path:filename>')
def download(filename):
    return send_from_directory(directory=app.config['UPLOAD_FOLDER'],filename=filename)

if __name__ == '__main__':
    db.create_all()
    app.run()